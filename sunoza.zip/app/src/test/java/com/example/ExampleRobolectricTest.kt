package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistSongCrossRef
import com.example.data.local.SeedCatalog
import com.example.data.local.SunozaDatabase
import com.example.data.remote.AuthorizedSourceValidator
import com.example.data.remote.SourceValidationResult
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: SunozaDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, SunozaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun appName_isSunoza() {
        assertEquals("Sunoza", context.getString(R.string.app_name))
    }

    @Test
    fun authorizedSourceValidator_enforcesAuthorizedSourcesOnly() {
        val allowed = AuthorizedSourceValidator.validateUrl(
            "https://archive.org/download/test_item/track.mp3",
            "https://creativecommons.org/licenses/by/4.0/",
        )
        assertTrue(allowed is SourceValidationResult.Authorized)

        val blockedHttp = AuthorizedSourceValidator.validateUrl(
            "http://archive.org/download/test_item/track.mp3",
        )
        assertTrue(blockedHttp is SourceValidationResult.Rejected)

        val blockedDomain = AuthorizedSourceValidator.validateUrl(
            "https://unauthorized-pirate-site.example.com/song.mp3",
        )
        assertTrue(blockedDomain is SourceValidationResult.Rejected)
    }

    @Test
    fun roomDao_seedsTracksAndManagesFavoritesAndPlaylists() = runTest {
        val dao = db.sunozaDao()
        val seedSongs = SeedCatalog.buildSeedSongs(context)
        val insertedIds = dao.insertSongs(seedSongs)
        assertEquals(4, insertedIds.size)

        val playlistId = dao.insertPlaylist(PlaylistEntity(name = "Night Drive"))
        dao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = playlistId, songId = insertedIds.first()))

        val playlists = dao.observePlaylistsWithSongs().first()
        assertEquals(1, playlists.size)
        assertEquals("Night Drive", playlists.first().playlist.name)
        assertEquals(1, playlists.first().songs.size)

        dao.setFavorite(insertedIds.last(), true)
        val favorites = dao.observeFavoriteSongs().first()
        assertTrue(favorites.any { it.id == insertedIds.last() })
    }
}
