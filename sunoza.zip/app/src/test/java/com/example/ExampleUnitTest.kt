package com.example

import com.example.model.LyricsParser
import com.example.model.SongColorGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun lyricsParser_parsesLrcAndFindsActiveLine() {
        val raw = """
            [00:06.00]Second line
            [00:00.00]First line
            [00:12.50]Third line
        """.trimIndent()

        val parsed = LyricsParser.parse(raw)
        assertEquals(3, parsed.size)
        assertEquals("First line", parsed[0].text)
        assertEquals(0L, parsed[0].timestampMs)
        assertEquals("Second line", parsed[1].text)
        assertEquals(6_000L, parsed[1].timestampMs)
        assertEquals("Third line", parsed[2].text)
        assertEquals(12_500L, parsed[2].timestampMs)

        assertEquals(0, LyricsParser.activeLineIndex(parsed, 1_500L))
        assertEquals(1, LyricsParser.activeLineIndex(parsed, 7_000L))
        assertEquals(2, LyricsParser.activeLineIndex(parsed, 13_000L))
    }

    @Test
    fun lyricsParser_autoSpacesPlainTextLyrics() {
        val raw = """
            Line one
            Line two
            Line three
        """.trimIndent()

        val parsed = LyricsParser.parse(raw, fallbackDurationMs = 15_000L)
        assertEquals(3, parsed.size)
        assertEquals(0L, parsed[0].timestampMs)
        assertEquals(5_000L, parsed[1].timestampMs)
        assertEquals(10_000L, parsed[2].timestampMs)
    }

    @Test
    fun songColorGenerator_createsOpaqueDistinctDarkColors() {
        val first = SongColorGenerator.nextSolidColorArgb()
        val second = SongColorGenerator.nextSolidColorArgb(avoidColorArgb = first)

        // Alpha byte must be 0xFF (opaque solid color)
        assertEquals(0xFFL, (first shr 24) and 0xFFL)
        assertEquals(0xFFL, (second shr 24) and 0xFFL)
        assertNotEquals(first, second)
        assertTrue(first != 0L)
    }
}
