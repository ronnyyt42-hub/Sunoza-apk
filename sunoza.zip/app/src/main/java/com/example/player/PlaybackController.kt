package com.example.player

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.remote.AuthorizedSourceValidator
import com.example.data.remote.SourceValidationResult
import com.example.model.Song
import com.example.model.SourceType
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PlaybackState(
    val isConnected: Boolean = false,
    val currentSongId: Long? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_ALL,
    val errorMessage: String? = null,
)

class PlaybackController(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null
    private var positionTickerJob: Job? = null

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state.asStateFlow()

    private var currentQueue: List<Song> = emptyList()
    private var pendingStartSongId: Long? = null
    private var pendingAutoPlay: Boolean = false

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.update { it.copy(isPlaying = isPlaying) }
            if (isPlaying) startPositionTicker() else stopPositionTicker()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val controller = mediaController ?: return
            _state.update {
                it.copy(
                    isBuffering = playbackState == Player.STATE_BUFFERING,
                    durationMs = controller.duration.takeIf { d -> d > 0 }
                        ?: currentSongDurationFallback(controller.currentMediaItem?.mediaId?.toLongOrNull()),
                    positionMs = controller.currentPosition.coerceAtLeast(0L),
                )
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val controller = mediaController ?: return
            val songId = mediaItem?.mediaId?.toLongOrNull()
            _state.update {
                it.copy(
                    currentSongId = songId,
                    positionMs = 0L,
                    durationMs = controller.duration.takeIf { d -> d > 0 }
                        ?: currentSongDurationFallback(songId),
                    errorMessage = null,
                )
            }
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _state.update { it.copy(shuffleEnabled = shuffleModeEnabled) }
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _state.update { it.copy(repeatMode = repeatMode) }
        }

        override fun onPlayerError(error: PlaybackException) {
            _state.update {
                it.copy(
                    isPlaying = false,
                    isBuffering = false,
                    errorMessage = error.localizedMessage ?: "Unable to play this audio track.",
                )
            }
        }
    }

    fun connect() {
        if (controllerFuture != null) return
        val sessionToken = SessionToken(
            context,
            ComponentName(context, SunozaPlaybackService::class.java),
        )
        val future = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                runCatching { future.get() }.onSuccess { controller ->
                    mediaController = controller
                    controller.addListener(playerListener)
                    controller.repeatMode = Player.REPEAT_MODE_ALL
                    val activeSongId = controller.currentMediaItem?.mediaId?.toLongOrNull()
                    _state.update {
                        it.copy(
                            isConnected = true,
                            currentSongId = activeSongId ?: it.currentSongId,
                            isPlaying = controller.isPlaying,
                            isBuffering = controller.playbackState == Player.STATE_BUFFERING,
                            positionMs = controller.currentPosition.coerceAtLeast(0L),
                            durationMs = controller.duration.takeIf { d -> d > 0 } ?: it.durationMs,
                            shuffleEnabled = controller.shuffleModeEnabled,
                            repeatMode = controller.repeatMode,
                        )
                    }
                    if (controller.isPlaying) startPositionTicker()
                    if (currentQueue.isNotEmpty() && controller.mediaItemCount == 0) {
                        applyQueueToController(
                            songs = currentQueue,
                            targetSongId = pendingStartSongId,
                            autoPlay = pendingAutoPlay,
                        )
                    }
                }
            },
            ContextCompat.getMainExecutor(context),
        )
    }

    fun syncQueue(songs: List<Song>, selectSongId: Long? = null, autoPlay: Boolean = false) {
        val authorizedSongs = songs.filter { song ->
            if (song.sourceType == SourceType.AUTHORIZED_ONLINE) {
                AuthorizedSourceValidator.validateUrl(song.audioUri) is SourceValidationResult.Authorized
            } else {
                true
            }
        }
        currentQueue = authorizedSongs
        pendingStartSongId = selectSongId
        pendingAutoPlay = autoPlay

        val controller = mediaController ?: return
        if (authorizedSongs.isEmpty()) {
            controller.clearMediaItems()
            _state.update { it.copy(currentSongId = null, isPlaying = false, positionMs = 0L, durationMs = 0L) }
            return
        }

        val currentControllerIds = (0 until controller.mediaItemCount).mapNotNull { idx ->
            controller.getMediaItemAt(idx).mediaId.toLongOrNull()
        }
        val newIds = authorizedSongs.map { it.id }

        if (currentControllerIds != newIds) {
            applyQueueToController(authorizedSongs, selectSongId, autoPlay)
        } else if (selectSongId != null) {
            val targetIdx = authorizedSongs.indexOfFirst { it.id == selectSongId }
            if (targetIdx >= 0) {
                val activeId = controller.currentMediaItem?.mediaId?.toLongOrNull()
                if (activeId != selectSongId) {
                    controller.seekToDefaultPosition(targetIdx)
                    controller.prepare()
                }
                if (autoPlay) controller.play()
            }
        }
    }

    fun playSong(song: Song, queue: List<Song>) {
        if (song.sourceType == SourceType.AUTHORIZED_ONLINE) {
            val check = AuthorizedSourceValidator.validateUrl(song.audioUri)
            if (check is SourceValidationResult.Rejected) {
                _state.update { it.copy(errorMessage = check.reason) }
                return
            }
        }
        syncQueue(songs = queue, selectSongId = song.id, autoPlay = true)
    }

    fun togglePlayPause() {
        val controller = mediaController ?: return
        if (controller.mediaItemCount == 0 && currentQueue.isNotEmpty()) {
            applyQueueToController(currentQueue, _state.value.currentSongId ?: currentQueue.first().id, autoPlay = true)
            return
        }
        if (controller.isPlaying) {
            controller.pause()
        } else {
            if (controller.playbackState == Player.STATE_IDLE) {
                controller.prepare()
            }
            controller.play()
        }
    }

    fun seekToNext() {
        val controller = mediaController ?: return
        if (controller.hasNextMediaItem()) {
            controller.seekToNextMediaItem()
            controller.prepare()
            controller.play()
        } else if (controller.mediaItemCount > 0) {
            controller.seekToDefaultPosition(0)
            controller.prepare()
            controller.play()
        }
    }

    fun seekToPrevious() {
        val controller = mediaController ?: return
        if (controller.hasPreviousMediaItem()) {
            controller.seekToPreviousMediaItem()
            controller.prepare()
            controller.play()
        } else if (controller.mediaItemCount > 0) {
            controller.seekToDefaultPosition(controller.mediaItemCount - 1)
            controller.prepare()
            controller.play()
        }
    }

    fun seekToPosition(positionMs: Long) {
        val controller = mediaController ?: return
        val clamped = positionMs.coerceAtLeast(0L)
        controller.seekTo(clamped)
        _state.update { it.copy(positionMs = clamped) }
    }

    fun toggleShuffle() {
        val controller = mediaController ?: return
        controller.shuffleModeEnabled = !controller.shuffleModeEnabled
    }

    fun cycleRepeatMode() {
        val controller = mediaController ?: return
        controller.repeatMode = when (controller.repeatMode) {
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_ALL
        }
    }

    fun clearError() {
        _state.update { it.copy(errorMessage = null) }
    }

    private fun applyQueueToController(
        songs: List<Song>,
        targetSongId: Long?,
        autoPlay: Boolean,
    ) {
        val controller = mediaController ?: return
        val mediaItems = songs.map { song ->
            MediaItem.Builder()
                .setMediaId(song.id.toString())
                .setUri(song.audioUri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .build()
                )
                .build()
        }
        val startIndex = targetSongId?.let { id -> songs.indexOfFirst { it.id == id } }
            ?.takeIf { it >= 0 }
            ?: 0

        controller.setMediaItems(mediaItems, startIndex, 0L)
        controller.prepare()
        if (autoPlay) {
            controller.play()
        }
        val selected = songs[startIndex]
        _state.update {
            it.copy(
                currentSongId = selected.id,
                durationMs = selected.durationMs,
                positionMs = 0L,
                errorMessage = null,
            )
        }
    }

    private fun currentSongDurationFallback(songId: Long?): Long {
        if (songId == null) return 0L
        return currentQueue.firstOrNull { it.id == songId }?.durationMs ?: 0L
    }

    private fun startPositionTicker() {
        if (positionTickerJob?.isActive == true) return
        positionTickerJob = scope.launch {
            while (true) {
                val controller = mediaController
                if (controller != null) {
                    val pos = controller.currentPosition.coerceAtLeast(0L)
                    val dur = controller.duration.takeIf { it > 0 }
                        ?: currentSongDurationFallback(controller.currentMediaItem?.mediaId?.toLongOrNull())
                    _state.update { it.copy(positionMs = pos, durationMs = dur) }
                }
                delay(100L)
            }
        }
    }

    private fun stopPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = null
    }

    fun release() {
        stopPositionTicker()
        mediaController?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        mediaController = null
    }
}
