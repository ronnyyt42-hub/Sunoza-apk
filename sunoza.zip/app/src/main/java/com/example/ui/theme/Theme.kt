package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val SunozaDarkColorScheme = darkColorScheme(
    primary = SunozaCoral,
    onPrimary = SunozaOnCoral,
    secondary = SunozaIvory,
    onSecondary = SunozaObsidian,
    tertiary = SunozaMint,
    background = SunozaObsidian,
    onBackground = SunozaIvory,
    surface = SunozaSurface,
    onSurface = SunozaIvory,
    surfaceVariant = SunozaSurfaceElevated,
    onSurfaceVariant = SunozaMutedText,
    outline = SunozaSubtleBorder,
    error = SunozaErrorRed,
)

private val SunozaShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
)

@Composable
fun SunozaTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = SunozaDarkColorScheme,
        typography = SunozaTypography,
        shapes = SunozaShapes,
        content = content,
    )
}
