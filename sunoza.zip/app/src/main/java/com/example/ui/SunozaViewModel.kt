package com.example.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.remote.OnlineTrackCandidate
import com.example.data.repository.MusicRepository
import com.example.model.PlaylistWithSongs
import com.example.model.Song
import com.example.player.PlaybackController
import com.example.player.PlaybackState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface QueueFilter {
    data object AllSongs : QueueFilter
    data object Favorites : QueueFilter
    data class Playlist(val playlistId: Long, val name: String) : QueueFilter

    val label: String
        get() = when (this) {
            AllSongs -> "All Songs"
            Favorites -> "Favourites"
            is Playlist -> name
        }
}

data class SunozaUiState(
    val isReady: Boolean = false,
    val allSongs: List<Song> = emptyList(),
    val favoriteSongs: List<Song> = emptyList(),
    val playlists: List<PlaylistWithSongs> = emptyList(),
    val activeQueueFilter: QueueFilter = QueueFilter.AllSongs,
    val activeQueue: List<Song> = emptyList(),
    val currentSong: Song? = null,
    val currentQueueIndex: Int = 0,
    val searchQuery: String = "",
    val searchResults: List<Song> = emptyList(),
    val onlineSearchQuery: String = "",
    val onlineCandidates: List<OnlineTrackCandidate> = emptyList(),
    val isOnlineSearching: Boolean = false,
    val statusMessage: String? = null,
    val playback: PlaybackState = PlaybackState(),
)

private data class LocalLibrarySnapshot(
    val allSongs: List<Song>,
    val favoriteSongs: List<Song>,
    val playlists: List<PlaylistWithSongs>,
)

private data class TransientUiControls(
    val isReady: Boolean,
    val queueFilter: QueueFilter,
    val searchQuery: String,
    val onlineSearchQuery: String,
    val onlineCandidates: List<OnlineTrackCandidate>,
    val isOnlineSearching: Boolean,
    val statusMessage: String?,
)

class SunozaViewModel(
    private val repository: MusicRepository,
    private val playbackController: PlaybackController,
) : ViewModel() {

    private val queueFilter = MutableStateFlow<QueueFilter>(QueueFilter.AllSongs)
    private val searchQuery = MutableStateFlow("")
    private val onlineSearchQuery = MutableStateFlow("")
    private val onlineCandidates = MutableStateFlow<List<OnlineTrackCandidate>>(emptyList())
    private val isOnlineSearching = MutableStateFlow(false)
    private val statusMessage = MutableStateFlow<String?>(null)
    private val isReady = MutableStateFlow(false)

    private val librarySnapshot = combine(
        repository.allSongs,
        repository.favoriteSongs,
        repository.playlists,
    ) { all, favs, lists ->
        LocalLibrarySnapshot(allSongs = all, favoriteSongs = favs, playlists = lists)
    }

    private val controlsSnapshot = combine(
        isReady,
        queueFilter,
        searchQuery,
        onlineSearchQuery,
        onlineCandidates,
        isOnlineSearching,
        statusMessage,
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        TransientUiControls(
            isReady = values[0] as Boolean,
            queueFilter = values[1] as QueueFilter,
            searchQuery = values[2] as String,
            onlineSearchQuery = values[3] as String,
            onlineCandidates = values[4] as List<OnlineTrackCandidate>,
            isOnlineSearching = values[5] as Boolean,
            statusMessage = values[6] as String?,
        )
    }

    val uiState: StateFlow<SunozaUiState> = combine(
        librarySnapshot,
        controlsSnapshot,
        playbackController.state,
    ) { library, controls, playback ->
        val resolvedQueue = when (val filter = controls.queueFilter) {
            QueueFilter.AllSongs -> library.allSongs
            QueueFilter.Favorites -> library.favoriteSongs.ifEmpty { library.allSongs }
            is QueueFilter.Playlist -> {
                val found = library.playlists.firstOrNull { it.id == filter.playlistId }
                found?.songs?.takeIf { it.isNotEmpty() } ?: library.allSongs
            }
        }

        val currentIdx = playback.currentSongId
            ?.let { id -> resolvedQueue.indexOfFirst { it.id == id } }
            ?.takeIf { it >= 0 }
            ?: 0

        val activeSong = resolvedQueue.getOrNull(currentIdx)
        val trimmedQuery = controls.searchQuery.trim()
        val filteredSongs = if (trimmedQuery.isEmpty()) {
            library.allSongs
        } else {
            library.allSongs.filter { song ->
                song.title.contains(trimmedQuery, ignoreCase = true) ||
                    song.artist.contains(trimmedQuery, ignoreCase = true) ||
                    song.lyricsRaw.contains(trimmedQuery, ignoreCase = true) ||
                    song.sourceLabel.contains(trimmedQuery, ignoreCase = true)
            }
        }

        SunozaUiState(
            isReady = controls.isReady,
            allSongs = library.allSongs,
            favoriteSongs = library.favoriteSongs,
            playlists = library.playlists,
            activeQueueFilter = controls.queueFilter,
            activeQueue = resolvedQueue,
            currentSong = activeSong,
            currentQueueIndex = currentIdx,
            searchQuery = controls.searchQuery,
            searchResults = filteredSongs,
            onlineSearchQuery = controls.onlineSearchQuery,
            onlineCandidates = controls.onlineCandidates,
            isOnlineSearching = controls.isOnlineSearching,
            statusMessage = controls.statusMessage ?: playback.errorMessage,
            playback = playback,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = SunozaUiState(),
    )

    init {
        playbackController.connect()
        viewModelScope.launch {
            repository.ensureSeeded()
            isReady.value = true
            searchAuthorizedOnline("")
        }
        viewModelScope.launch {
            uiState.collect { state ->
                if (state.isReady && state.activeQueue.isNotEmpty() && state.playback.isConnected) {
                    val currentId = state.playback.currentSongId
                    val hasCurrentInQueue = currentId != null && state.activeQueue.any { it.id == currentId }
                    if (!hasCurrentInQueue) {
                        playbackController.syncQueue(
                            songs = state.activeQueue,
                            selectSongId = state.activeQueue.first().id,
                            autoPlay = false,
                        )
                    } else {
                        playbackController.syncQueue(
                            songs = state.activeQueue,
                            selectSongId = currentId,
                            autoPlay = false,
                        )
                    }
                }
            }
        }
    }

    fun onSwipeToQueueIndex(index: Int) {
        val queue = uiState.value.activeQueue
        val target = queue.getOrNull(index) ?: return
        if (target.id != uiState.value.playback.currentSongId) {
            playbackController.playSong(target, queue)
        }
    }

    fun playSongInCurrentOrAllQueue(song: Song) {
        val state = uiState.value
        val inCurrent = state.activeQueue.any { it.id == song.id }
        val targetQueue = if (inCurrent) {
            state.activeQueue
        } else {
            queueFilter.value = QueueFilter.AllSongs
            state.allSongs
        }
        playbackController.playSong(song, targetQueue)
    }

    fun playPlaylist(playlist: PlaylistWithSongs, startSong: Song? = null) {
        if (playlist.songs.isEmpty()) {
            statusMessage.value = "Playlist \"${playlist.name}\" is empty. Add songs first."
            return
        }
        queueFilter.value = QueueFilter.Playlist(playlist.id, playlist.name)
        val target = startSong ?: playlist.songs.first()
        playbackController.playSong(target, playlist.songs)
    }

    fun playFavorites(startSong: Song? = null) {
        val favs = uiState.value.favoriteSongs
        if (favs.isEmpty()) {
            statusMessage.value = "No favourite songs yet. Tap the heart on any track."
            return
        }
        queueFilter.value = QueueFilter.Favorites
        val target = startSong ?: favs.first()
        playbackController.playSong(target, favs)
    }

    fun playAllSongs(startSong: Song? = null) {
        val all = uiState.value.allSongs
        if (all.isEmpty()) return
        queueFilter.value = QueueFilter.AllSongs
        val target = startSong ?: all.first()
        playbackController.playSong(target, all)
    }

    fun togglePlayPause() = playbackController.togglePlayPause()

    fun nextSong() = playbackController.seekToNext()

    fun previousSong() = playbackController.seekToPrevious()

    fun seekTo(positionMs: Long) = playbackController.seekToPosition(positionMs)

    fun toggleShuffle() = playbackController.toggleShuffle()

    fun cycleRepeatMode() = playbackController.cycleRepeatMode()

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun updateOnlineSearchQuery(query: String) {
        onlineSearchQuery.value = query
    }

    fun searchAuthorizedOnline(query: String = onlineSearchQuery.value) {
        viewModelScope.launch {
            isOnlineSearching.value = true
            repository.searchAuthorizedOnlineTracks(query)
                .onSuccess { results ->
                    onlineCandidates.value = results
                }
                .onFailure { err ->
                    statusMessage.value = err.localizedMessage ?: "Unable to reach authorized catalog."
                }
            isOnlineSearching.value = false
        }
    }

    fun importAndPlayAuthorizedCandidate(candidate: OnlineTrackCandidate) {
        viewModelScope.launch {
            repository.addAuthorizedOnlineCandidate(candidate)
                .onSuccess { song ->
                    queueFilter.value = QueueFilter.AllSongs
                    val updatedQueue = (uiState.value.allSongs + song).distinctBy { it.id }
                    playbackController.playSong(song, updatedQueue)
                    statusMessage.value = "Playing authorized stream: ${song.title}"
                }
                .onFailure { err ->
                    statusMessage.value = err.message ?: "Stream rejected by source policy."
                }
        }
    }

    fun addAuthorizedStreamByUrl(url: String, title: String, artist: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.addAuthorizedStreamByUrl(url, title, artist)
                .onSuccess { song ->
                    queueFilter.value = QueueFilter.AllSongs
                    val updatedQueue = (uiState.value.allSongs + song).distinctBy { it.id }
                    playbackController.playSong(song, updatedQueue)
                    statusMessage.value = "Added authorized stream: ${song.title}"
                    onSuccess()
                }
                .onFailure { err ->
                    statusMessage.value = err.message ?: "Only authorized music sources are permitted."
                }
        }
    }

    fun importOfflineFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val ids = repository.importOfflineAudioFiles(uris)
            if (ids.isNotEmpty()) {
                queueFilter.value = QueueFilter.AllSongs
                statusMessage.value = "Imported ${ids.size} offline audio file${if (ids.size > 1) "s" else ""}"
                val firstId = ids.first()
                val updatedList = repository.allSongs.first { songs -> songs.any { it.id == firstId } }
                updatedList.firstOrNull { it.id == firstId }?.let { imported ->
                    playbackController.playSong(imported, updatedList)
                }
            }
        }
    }

    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            repository.toggleFavorite(song.id, !song.isFavorite)
        }
    }

    fun updateLyrics(songId: Long, lyricsRaw: String) {
        viewModelScope.launch {
            repository.updateLyrics(songId, lyricsRaw)
            statusMessage.value = "Synchronized lyrics saved"
        }
    }

    fun randomizeSongColor(song: Song) {
        viewModelScope.launch {
            repository.randomizeSongColor(song.id, song.backgroundColorArgb)
        }
    }

    fun createPlaylist(name: String, initialSongId: Long? = null) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val playlistId = repository.createPlaylist(clean)
            if (initialSongId != null) {
                repository.addSongToPlaylist(playlistId, initialSongId)
                statusMessage.value = "Created \"$clean\" and added song"
            } else {
                statusMessage.value = "Created playlist \"$clean\""
            }
        }
    }

    fun renamePlaylist(playlistId: Long, newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch {
            repository.renamePlaylist(playlistId, newName)
            statusMessage.value = "Playlist renamed"
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            if ((queueFilter.value as? QueueFilter.Playlist)?.playlistId == playlistId) {
                queueFilter.value = QueueFilter.AllSongs
            }
            repository.deletePlaylist(playlistId)
            statusMessage.value = "Playlist deleted"
        }
    }

    fun toggleSongInPlaylist(playlist: PlaylistWithSongs, songId: Long) {
        viewModelScope.launch {
            val exists = playlist.songs.any { it.id == songId }
            if (exists) {
                repository.removeSongFromPlaylist(playlist.id, songId)
                statusMessage.value = "Removed from ${playlist.name}"
            } else {
                repository.addSongToPlaylist(playlist.id, songId)
                statusMessage.value = "Added to ${playlist.name}"
            }
        }
    }

    fun deleteSong(song: Song) {
        viewModelScope.launch {
            repository.deleteSong(song.id)
            statusMessage.value = "Removed \"${song.title}\""
        }
    }

    fun clearStatusMessage() {
        statusMessage.value = null
        playbackController.clearError()
    }

    class Factory(
        private val repository: MusicRepository,
        private val playbackController: PlaybackController,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SunozaViewModel(repository, playbackController) as T
        }
    }
}
