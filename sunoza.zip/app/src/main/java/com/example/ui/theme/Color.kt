package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SunozaObsidian = Color(0xFF0E0E12)
val SunozaSurface = Color(0xFF16161C)
val SunozaSurfaceElevated = Color(0xFF1F1F28)
val SunozaCoral = Color(0xFFFF6B4A)
val SunozaOnCoral = Color(0xFF1A0905)
val SunozaIvory = Color(0xFFF6F6F9)
val SunozaMutedText = Color(0xFFB4B4C2)
val SunozaSubtleBorder = Color(0xFF2B2B36)
val SunozaErrorRed = Color(0xFFFF6E6E)
val SunozaMint = Color(0xFF4CD995)
