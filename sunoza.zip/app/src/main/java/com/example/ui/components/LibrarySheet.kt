package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.remote.OnlineTrackCandidate
import com.example.model.PlaylistWithSongs
import com.example.model.Song
import com.example.model.SourceType
import com.example.ui.SunozaUiState
import com.example.ui.theme.SunozaCoral
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaMint
import com.example.ui.theme.SunozaMutedText
import com.example.ui.theme.SunozaSubtleBorder
import com.example.ui.theme.SunozaSurface
import com.example.ui.theme.SunozaSurfaceElevated

enum class LibraryTab(val title: String) {
    SEARCH("Search"),
    FAVOURITES("Favourites"),
    PLAYLISTS("Playlists"),
    ONLINE("Online CC"),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibrarySheet(
    uiState: SunozaUiState,
    initialTab: LibraryTab,
    onDismiss: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onOnlineSearchQueryChange: (String) -> Unit,
    onSearchOnline: () -> Unit,
    onPlaySong: (Song) -> Unit,
    onPlayFavorites: () -> Unit,
    onPlayPlaylist: (PlaylistWithSongs) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onOpenAddToPlaylist: (Song) -> Unit,
    onDeleteSong: (Song) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onRenamePlaylist: (Long, String) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onRemoveSongFromPlaylist: (PlaylistWithSongs, Long) -> Unit,
    onImportOfflineAudio: () -> Unit,
    onPlayOnlineCandidate: (OnlineTrackCandidate) -> Unit,
    onOpenAuthorizedUrlDialog: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTab by remember(initialTab) { mutableStateOf(initialTab) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var playlistToRename by remember { mutableStateOf<PlaylistWithSongs?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SunozaSurface,
        contentColor = SunozaIvory,
        modifier = Modifier.testTag("library_bottom_sheet"),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .navigationBarsPadding(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = "Sunoza Library",
                    style = MaterialTheme.typography.headlineMedium,
                    color = SunozaIvory,
                )
                FilledTonalButton(
                    onClick = onImportOfflineAudio,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = SunozaSurfaceElevated,
                        contentColor = SunozaIvory,
                    ),
                    modifier = Modifier.testTag("sheet_import_offline_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.import_offline))
                }
            }

            TabRow(
                selectedTabIndex = selectedTab.ordinal,
                containerColor = SunozaSurface,
                contentColor = SunozaCoral,
                modifier = Modifier.padding(top = 8.dp),
            ) {
                LibraryTab.entries.forEach { tab ->
                    Tab(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        text = {
                            Text(
                                text = tab.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        modifier = Modifier.testTag("library_tab_${tab.name.lowercase()}"),
                    )
                }
            }

            when (selectedTab) {
                LibraryTab.SEARCH -> SearchSongsTab(
                    query = uiState.searchQuery,
                    songs = uiState.searchResults,
                    currentSongId = uiState.currentSong?.id,
                    onQueryChange = onSearchQueryChange,
                    onPlaySong = {
                        onPlaySong(it)
                        onDismiss()
                    },
                    onToggleFavorite = onToggleFavorite,
                    onOpenAddToPlaylist = onOpenAddToPlaylist,
                    onDeleteSong = onDeleteSong,
                )

                LibraryTab.FAVOURITES -> FavouritesTab(
                    favorites = uiState.favoriteSongs,
                    currentSongId = uiState.currentSong?.id,
                    onPlayAllFavorites = {
                        onPlayFavorites()
                        onDismiss()
                    },
                    onPlaySong = {
                        onPlaySong(it)
                        onDismiss()
                    },
                    onToggleFavorite = onToggleFavorite,
                    onOpenAddToPlaylist = onOpenAddToPlaylist,
                )

                LibraryTab.PLAYLISTS -> PlaylistsTab(
                    playlists = uiState.playlists,
                    onCreateClick = { showCreatePlaylistDialog = true },
                    onPlayPlaylist = {
                        onPlayPlaylist(it)
                        onDismiss()
                    },
                    onRenameClick = { playlistToRename = it },
                    onDeleteClick = { onDeletePlaylist(it.id) },
                    onRemoveSong = onRemoveSongFromPlaylist,
                    onPlaySong = {
                        onPlaySong(it)
                        onDismiss()
                    },
                )

                LibraryTab.ONLINE -> AuthorizedOnlineTab(
                    query = uiState.onlineSearchQuery,
                    isSearching = uiState.isOnlineSearching,
                    candidates = uiState.onlineCandidates,
                    onQueryChange = onOnlineSearchQueryChange,
                    onSearchSubmit = onSearchOnline,
                    onPlayCandidate = {
                        onPlayOnlineCandidate(it)
                        onDismiss()
                    },
                    onOpenAddUrl = onOpenAuthorizedUrlDialog,
                )
            }
        }
    }

    if (showCreatePlaylistDialog) {
        CreateOrRenamePlaylistDialog(
            title = "New Playlist",
            confirmLabel = "Create",
            onDismiss = { showCreatePlaylistDialog = false },
            onConfirm = onCreatePlaylist,
        )
    }

    playlistToRename?.let { target ->
        CreateOrRenamePlaylistDialog(
            title = "Rename Playlist",
            initialName = target.name,
            confirmLabel = "Save",
            onDismiss = { playlistToRename = null },
            onConfirm = { newName -> onRenamePlaylist(target.id, newName) },
        )
    }
}

@Composable
private fun SearchSongsTab(
    query: String,
    songs: List<Song>,
    currentSongId: Long?,
    onQueryChange: (String) -> Unit,
    onPlaySong: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onOpenAddToPlaylist: (Song) -> Unit,
    onDeleteSong: (Song) -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text(stringResource(R.string.search_placeholder)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQueryChange("") }) {
                        Icon(Icons.Filled.Close, contentDescription = "Clear search")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .testTag("music_search_input"),
        )

        if (songs.isEmpty()) {
            EmptyLibraryPlaceholder(
                title = "No matching tracks",
                subtitle = "Try another song title, singer name, or import offline audio.",
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(songs, key = { it.id }) { song ->
                    SongLibraryRow(
                        song = song,
                        isPlaying = song.id == currentSongId,
                        onClick = { onPlaySong(song) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onAddToPlaylist = { onOpenAddToPlaylist(song) },
                        onDelete = if (song.sourceType != SourceType.BUNDLED) {
                            { onDeleteSong(song) }
                        } else {
                            null
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun FavouritesTab(
    favorites: List<Song>,
    currentSongId: Long?,
    onPlayAllFavorites: () -> Unit,
    onPlaySong: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onOpenAddToPlaylist: (Song) -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        if (favorites.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "${favorites.size} favourite track${if (favorites.size == 1) "" else "s"}",
                    style = MaterialTheme.typography.titleMedium,
                    color = SunozaMutedText,
                )
                Button(
                    onClick = onPlayAllFavorites,
                    modifier = Modifier.testTag("play_all_favourites_button"),
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Play Favourites")
                }
            }
        }

        if (favorites.isEmpty()) {
            EmptyLibraryPlaceholder(
                title = "No favourites yet",
                subtitle = "Tap the heart icon on any song to keep it here.",
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(favorites, key = { it.id }) { song ->
                    SongLibraryRow(
                        song = song,
                        isPlaying = song.id == currentSongId,
                        onClick = { onPlaySong(song) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onAddToPlaylist = { onOpenAddToPlaylist(song) },
                        onDelete = null,
                    )
                }
            }
        }
    }
}

@Composable
private fun PlaylistsTab(
    playlists: List<PlaylistWithSongs>,
    onCreateClick: () -> Unit,
    onPlayPlaylist: (PlaylistWithSongs) -> Unit,
    onRenameClick: (PlaylistWithSongs) -> Unit,
    onDeleteClick: (PlaylistWithSongs) -> Unit,
    onRemoveSong: (PlaylistWithSongs, Long) -> Unit,
    onPlaySong: (Song) -> Unit,
) {
    var expandedPlaylistId by remember { mutableStateOf<Long?>(null) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "${playlists.size} playlist${if (playlists.size == 1) "" else "s"}",
                style = MaterialTheme.typography.titleMedium,
                color = SunozaMutedText,
            )
            Button(
                onClick = onCreateClick,
                modifier = Modifier.testTag("create_playlist_button"),
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.create_playlist))
            }
        }

        if (playlists.isEmpty()) {
            EmptyLibraryPlaceholder(
                title = "No playlists yet",
                subtitle = "Create a playlist to organize your offline and online songs.",
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(playlists, key = { it.id }) { playlist ->
                    val isExpanded = expandedPlaylistId == playlist.id
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(SunozaSurfaceElevated)
                            .border(1.dp, SunozaSubtleBorder, RoundedCornerShape(16.dp))
                            .clickable {
                                expandedPlaylistId = if (isExpanded) null else playlist.id
                            }
                            .padding(14.dp)
                            .testTag("playlist_card_${playlist.id}"),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                                contentDescription = null,
                                tint = SunozaCoral,
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = playlist.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = SunozaIvory,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = "${playlist.songs.size} song${if (playlist.songs.size == 1) "" else "s"}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = SunozaMutedText,
                                )
                            }
                            IconButton(
                                onClick = { onPlayPlaylist(playlist) },
                                modifier = Modifier.testTag("play_playlist_${playlist.id}"),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = "Play playlist",
                                    tint = SunozaIvory,
                                )
                            }
                            IconButton(onClick = { onRenameClick(playlist) }) {
                                Icon(
                                    imageVector = Icons.Filled.Edit,
                                    contentDescription = "Rename playlist",
                                    tint = SunozaMutedText,
                                )
                            }
                            IconButton(onClick = { onDeleteClick(playlist) }) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = "Delete playlist",
                                    tint = SunozaMutedText,
                                )
                            }
                        }

                        AnimatedVisibility(visible = isExpanded) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                if (playlist.songs.isEmpty()) {
                                    Text(
                                        text = "Tap the playlist icon on any song to add tracks here.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = SunozaMutedText,
                                    )
                                } else {
                                    playlist.songs.forEach { song ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(SunozaSurface)
                                                .clickable { onPlaySong(song) }
                                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(12.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(song.backgroundColorArgb)),
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = song.title,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Medium,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                                Text(
                                                    text = song.artist,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = SunozaMutedText,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            }
                                            IconButton(onClick = { onRemoveSong(playlist, song.id) }) {
                                                Icon(
                                                    imageVector = Icons.Filled.Close,
                                                    contentDescription = "Remove from playlist",
                                                    tint = SunozaMutedText,
                                                    modifier = Modifier.size(18.dp),
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthorizedOnlineTab(
    query: String,
    isSearching: Boolean,
    candidates: List<OnlineTrackCandidate>,
    onQueryChange: (String) -> Unit,
    onSearchSubmit: () -> Unit,
    onPlayCandidate: (OnlineTrackCandidate) -> Unit,
    onOpenAddUrl: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SunozaSurfaceElevated)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(
                imageVector = Icons.Filled.VerifiedUser,
                contentDescription = null,
                tint = SunozaMint,
                modifier = Modifier.size(18.dp),
            )
            Text(
                text = stringResource(R.string.authorized_sources_subtitle),
                style = MaterialTheme.typography.labelMedium,
                color = SunozaIvory,
                modifier = Modifier.weight(1f),
            )
            FilledTonalButton(
                onClick = onOpenAddUrl,
                modifier = Modifier.testTag("add_authorized_url_button"),
            ) {
                Icon(Icons.Filled.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add URL")
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                placeholder = { Text("Search Creative Commons audio…") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("online_search_input"),
            )
            Button(
                onClick = onSearchSubmit,
                modifier = Modifier.testTag("online_search_button"),
            ) {
                Text("Find")
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (isSearching) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator(color = SunozaCoral)
            }
        } else if (candidates.isEmpty()) {
            EmptyLibraryPlaceholder(
                title = "No authorized streams found",
                subtitle = "Try another keyword or add a verified Creative Commons HTTPS URL.",
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(candidates, key = { it.id }) { candidate ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(SunozaSurfaceElevated)
                            .clickable { onPlayCandidate(candidate) }
                            .padding(14.dp)
                            .testTag("online_candidate_${candidate.id}"),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CloudQueue,
                            contentDescription = null,
                            tint = SunozaMint,
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = candidate.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = SunozaIvory,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = "${candidate.artist} · ${candidate.providerName}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SunozaMutedText,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = "${candidate.licenseName} · ${formatDuration(candidate.durationMs)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = SunozaMint,
                            )
                        }
                        Icon(
                            imageVector = Icons.Filled.PlayArrow,
                            contentDescription = "Stream track",
                            tint = SunozaIvory,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SongLibraryRow(
    song: Song,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onDelete: (() -> Unit)?,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isPlaying) Color(song.backgroundColorArgb) else SunozaSurfaceElevated)
            .border(
                width = 1.dp,
                color = if (isPlaying) SunozaCoral else SunozaSubtleBorder,
                shape = RoundedCornerShape(14.dp),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("library_song_${song.id}"),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(song.backgroundColorArgb)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = when (song.sourceType) {
                    SourceType.OFFLINE_LOCAL -> Icons.Filled.AudioFile
                    SourceType.AUTHORIZED_ONLINE -> Icons.Filled.CloudQueue
                    SourceType.BUNDLED -> Icons.Filled.PlayArrow
                },
                contentDescription = null,
                tint = SunozaIvory,
                modifier = Modifier.size(20.dp),
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = if (isPlaying) FontWeight.Bold else FontWeight.Medium,
                color = SunozaIvory,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = "${song.artist} · ${song.sourceType.displayLabel}",
                style = MaterialTheme.typography.labelMedium,
                color = SunozaMutedText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        IconButton(
            onClick = onToggleFavorite,
            modifier = Modifier.testTag("row_fav_${song.id}"),
        ) {
            Icon(
                imageVector = if (song.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = stringResource(R.string.toggle_favourite),
                tint = if (song.isFavorite) SunozaCoral else SunozaMutedText,
            )
        }

        IconButton(
            onClick = onAddToPlaylist,
            modifier = Modifier.testTag("row_playlist_${song.id}"),
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.PlaylistAdd,
                contentDescription = stringResource(R.string.add_to_playlist),
                tint = SunozaMutedText,
            )
        }

        if (onDelete != null) {
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = "Remove song",
                    tint = SunozaMutedText,
                )
            }
        }
    }
}

@Composable
private fun EmptyLibraryPlaceholder(
    title: String,
    subtitle: String,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            imageVector = Icons.Outlined.FavoriteBorder,
            contentDescription = null,
            tint = SunozaMutedText,
            modifier = Modifier.size(36.dp),
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = SunozaIvory,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = SunozaMutedText,
        )
    }
}
