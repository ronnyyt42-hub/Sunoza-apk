package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.Song
import com.example.ui.SunozaUiState
import com.example.ui.SunozaViewModel
import com.example.ui.theme.SunozaCoral
import com.example.ui.theme.SunozaIvory
import com.example.ui.theme.SunozaObsidian
import com.example.ui.theme.SunozaSurface
import kotlinx.coroutines.flow.distinctUntilChanged

@Composable
fun FullScreenPlayerScreen(
    uiState: SunozaUiState,
    viewModel: SunozaViewModel,
    onPickOfflineAudio: () -> Unit,
) {
    var activeSheetTab by remember { mutableStateOf<LibraryTab?>(null) }
    var songForLyricsEdit by remember { mutableStateOf<Song?>(null) }
    var songForPlaylistAdd by remember { mutableStateOf<Song?>(null) }
    var showAuthorizedUrlDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.statusMessage) {
        val msg = uiState.statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    BackHandler(enabled = activeSheetTab != null) {
        activeSheetTab = null
    }

    Scaffold(
        containerColor = SunozaObsidian,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = SunozaSurface,
                    contentColor = SunozaIvory,
                )
            }
        },
    ) { _ ->
        val queue = uiState.activeQueue
        if (!uiState.isReady || queue.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SunozaObsidian),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator(color = SunozaCoral)
            }
            return@Scaffold
        }

        val pagerState = rememberPagerState(
            initialPage = uiState.currentQueueIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0)),
            pageCount = { queue.size },
        )

        // Sync user vertical swipe (up = next song, down = previous song) with MediaController
        LaunchedEffect(pagerState, queue) {
            snapshotFlow { pagerState.settledPage }
                .distinctUntilChanged()
                .collect { page ->
                    if (page in queue.indices) {
                        viewModel.onSwipeToQueueIndex(page)
                    }
                }
        }

        // Sync external playback changes (Next/Prev buttons, library tap, auto-advance) to VerticalPager
        LaunchedEffect(uiState.currentQueueIndex, queue.size) {
            val target = uiState.currentQueueIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0))
            if (pagerState.currentPage != target && !pagerState.isScrollInProgress) {
                pagerState.animateScrollToPage(target)
            }
        }

        VerticalPager(
            state = pagerState,
            key = { index -> queue[index].id },
            modifier = Modifier
                .fillMaxSize()
                .testTag("song_vertical_pager"),
        ) { pageIndex ->
            val song = queue[pageIndex]
            val isCurrentPage = pageIndex == uiState.currentQueueIndex

            // Pure randomly generated plain solid background color per song — zero gradients, images, patterns, or textures
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(song.backgroundColorArgb))
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .testTag("song_page_${song.id}"),
                contentAlignment = Alignment.TopCenter,
            ) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 600.dp)
                        .fillMaxSize()
                        .padding(horizontal = 22.dp, vertical = 12.dp),
                ) {
                    PlayerTopBar(
                        queueLabel = uiState.activeQueueFilter.label,
                        trackPositionText = "${pageIndex + 1} / ${queue.size}",
                        onOpenSearch = { activeSheetTab = LibraryTab.SEARCH },
                        onOpenPlaylists = { activeSheetTab = LibraryTab.PLAYLISTS },
                        onOpenOnline = { activeSheetTab = LibraryTab.ONLINE },
                        onPickOffline = onPickOfflineAudio,
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    SongIdentityHeader(
                        song = song,
                        onToggleFavorite = { viewModel.toggleFavorite(song) },
                        onAddToPlaylist = { songForPlaylistAdd = song },
                        onEditLyrics = { songForLyricsEdit = song },
                        onRandomizeColor = { viewModel.randomizeSongColor(song) },
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Synchronized lyrics stage
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                    ) {
                        SynchronizedLyricsView(
                            lyrics = song.parsedLyrics,
                            positionMs = if (isCurrentPage) uiState.playback.positionMs else 0L,
                            isActivePage = isCurrentPage,
                            onSeekToLine = { timestampMs ->
                                if (isCurrentPage) {
                                    viewModel.seekTo(timestampMs)
                                }
                            },
                            onEditLyrics = { songForLyricsEdit = song },
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    PlayerControlsPanel(
                        isPlaying = if (isCurrentPage) uiState.playback.isPlaying else false,
                        isBuffering = if (isCurrentPage) uiState.playback.isBuffering else false,
                        positionMs = if (isCurrentPage) uiState.playback.positionMs else 0L,
                        durationMs = if (isCurrentPage && uiState.playback.durationMs > 0L) {
                            uiState.playback.durationMs
                        } else {
                            song.durationMs
                        },
                        shuffleEnabled = uiState.playback.shuffleEnabled,
                        repeatMode = uiState.playback.repeatMode,
                        onPlayPause = { viewModel.togglePlayPause() },
                        onPrevious = { viewModel.previousSong() },
                        onNext = { viewModel.nextSong() },
                        onSeekTo = { viewModel.seekTo(it) },
                        onToggleShuffle = { viewModel.toggleShuffle() },
                        onCycleRepeat = { viewModel.cycleRepeatMode() },
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    SwipeHintFooter(
                        hasPrevious = pageIndex > 0,
                        hasNext = pageIndex < queue.lastIndex,
                    )
                }
            }
        }
    }

    activeSheetTab?.let { tab ->
        LibrarySheet(
            uiState = uiState,
            initialTab = tab,
            onDismiss = { activeSheetTab = null },
            onSearchQueryChange = viewModel::updateSearchQuery,
            onOnlineSearchQueryChange = viewModel::updateOnlineSearchQuery,
            onSearchOnline = { viewModel.searchAuthorizedOnline() },
            onPlaySong = viewModel::playSongInCurrentOrAllQueue,
            onPlayFavorites = { viewModel.playFavorites() },
            onPlayPlaylist = { viewModel.playPlaylist(it) },
            onToggleFavorite = viewModel::toggleFavorite,
            onOpenAddToPlaylist = { songForPlaylistAdd = it },
            onDeleteSong = viewModel::deleteSong,
            onCreatePlaylist = { name -> viewModel.createPlaylist(name) },
            onRenamePlaylist = viewModel::renamePlaylist,
            onDeletePlaylist = viewModel::deletePlaylist,
            onRemoveSongFromPlaylist = viewModel::toggleSongInPlaylist,
            onImportOfflineAudio = onPickOfflineAudio,
            onPlayOnlineCandidate = viewModel::importAndPlayAuthorizedCandidate,
            onOpenAuthorizedUrlDialog = { showAuthorizedUrlDialog = true },
        )
    }

    songForLyricsEdit?.let { song ->
        LyricsEditorDialog(
            song = song,
            onDismiss = { songForLyricsEdit = null },
            onSave = { updated -> viewModel.updateLyrics(song.id, updated) },
        )
    }

    songForPlaylistAdd?.let { song ->
        AddToPlaylistDialog(
            song = song,
            playlists = uiState.playlists,
            onDismiss = { songForPlaylistAdd = null },
            onToggleSongInPlaylist = viewModel::toggleSongInPlaylist,
            onCreatePlaylistWithSong = { name, id -> viewModel.createPlaylist(name, id) },
        )
    }

    if (showAuthorizedUrlDialog) {
        AuthorizedStreamUrlDialog(
            onDismiss = { showAuthorizedUrlDialog = false },
            onAddUrl = { url, title, artist ->
                viewModel.addAuthorizedStreamByUrl(url, title, artist) {
                    showAuthorizedUrlDialog = false
                    activeSheetTab = null
                }
            },
        )
    }
}

@Composable
private fun PlayerTopBar(
    queueLabel: String,
    trackPositionText: String,
    onOpenSearch: () -> Unit,
    onOpenPlaylists: () -> Unit,
    onOpenOnline: () -> Unit,
    onPickOffline: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(Color.Black.copy(alpha = 0.24f))
                .clickable(onClick = onOpenPlaylists)
                .padding(horizontal = 14.dp, vertical = 8.dp)
                .testTag("queue_pill_button"),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                contentDescription = stringResource(R.string.open_library),
                tint = SunozaIvory,
                modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "$queueLabel · $trackPositionText",
                style = MaterialTheme.typography.labelMedium,
                color = SunozaIvory,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onPickOffline,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("top_import_offline_button"),
            ) {
                Icon(
                    imageVector = Icons.Filled.FolderOpen,
                    contentDescription = stringResource(R.string.import_offline),
                    tint = SunozaIvory,
                )
            }
            IconButton(
                onClick = onOpenOnline,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("top_online_cc_button"),
            ) {
                Icon(
                    imageVector = Icons.Filled.CloudQueue,
                    contentDescription = stringResource(R.string.authorized_online),
                    tint = SunozaIvory,
                )
            }
            IconButton(
                onClick = onOpenSearch,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("top_search_button"),
            ) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = stringResource(R.string.open_library),
                    tint = SunozaIvory,
                )
            }
        }
    }
}

@Composable
private fun SongIdentityHeader(
    song: Song,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onEditLyrics: () -> Unit,
    onRandomizeColor: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(Color.Black.copy(alpha = 0.22f))
                .padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "${song.sourceType.displayLabel} · ${song.licenseName}",
                style = MaterialTheme.typography.labelMedium,
                color = SunozaIvory.copy(alpha = 0.85f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = SunozaIvory,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.testTag("player_song_title"),
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = song.artist,
                    style = MaterialTheme.typography.titleMedium,
                    color = SunozaIvory.copy(alpha = 0.78f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.testTag("player_song_artist"),
                )
            }

            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("player_favorite_button"),
            ) {
                Icon(
                    imageVector = if (song.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = stringResource(R.string.toggle_favourite),
                    tint = if (song.isFavorite) SunozaCoral else SunozaIvory,
                    modifier = Modifier.size(26.dp),
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CompactSolidActionChip(
                icon = Icons.AutoMirrored.Filled.PlaylistAdd,
                label = "Playlist",
                onClick = onAddToPlaylist,
                tag = "player_add_to_playlist_chip",
            )
            CompactSolidActionChip(
                icon = Icons.Filled.Lyrics,
                label = "Lyrics",
                onClick = onEditLyrics,
                tag = "player_edit_lyrics_chip",
            )
            CompactSolidActionChip(
                icon = Icons.Filled.ColorLens,
                label = "Color",
                onClick = onRandomizeColor,
                tag = "player_new_color_chip",
            )
        }
    }
}

@Composable
private fun CompactSolidActionChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    tag: String,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.Black.copy(alpha = 0.22f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = SunozaIvory.copy(alpha = 0.9f),
            modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = SunozaIvory.copy(alpha = 0.9f),
        )
    }
}

@Composable
private fun SwipeHintFooter(
    hasPrevious: Boolean,
    hasNext: Boolean,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (hasNext) {
            Icon(
                imageVector = Icons.Filled.KeyboardArrowUp,
                contentDescription = null,
                tint = SunozaIvory.copy(alpha = 0.5f),
                modifier = Modifier.size(16.dp),
            )
        }
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = stringResource(R.string.swipe_hint),
            style = MaterialTheme.typography.labelMedium,
            color = SunozaIvory.copy(alpha = 0.55f),
        )
        Spacer(modifier = Modifier.width(4.dp))
        if (hasPrevious) {
            Icon(
                imageVector = Icons.Filled.KeyboardArrowDown,
                contentDescription = null,
                tint = SunozaIvory.copy(alpha = 0.5f),
                modifier = Modifier.size(16.dp),
            )
        }
    }
}
