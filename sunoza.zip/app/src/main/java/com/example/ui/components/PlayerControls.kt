package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import com.example.R
import com.example.ui.theme.SunozaCoral
import com.example.ui.theme.SunozaIvory
import java.util.Locale

@Composable
fun PlayerControlsPanel(
    isPlaying: Boolean,
    isBuffering: Boolean,
    positionMs: Long,
    durationMs: Long,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val safeDuration = durationMs.coerceAtLeast(1_000L)
    var isDragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }

    val liveFraction = (positionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
    val sliderValue = if (isDragging) dragFraction else liveFraction
    val displayedPositionMs = if (isDragging) (dragFraction * safeDuration).toLong() else positionMs

    Column(modifier = modifier.fillMaxWidth()) {
        Slider(
            value = sliderValue,
            onValueChange = { fraction ->
                isDragging = true
                dragFraction = fraction
            },
            onValueChangeFinished = {
                isDragging = false
                onSeekTo((dragFraction * safeDuration).toLong())
            },
            colors = SliderDefaults.colors(
                thumbColor = SunozaIvory,
                activeTrackColor = SunozaIvory,
                inactiveTrackColor = SunozaIvory.copy(alpha = 0.24f),
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("playback_seek_slider"),
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = formatDuration(displayedPositionMs),
                style = MaterialTheme.typography.labelSmall,
                color = SunozaIvory.copy(alpha = 0.8f),
                modifier = Modifier.testTag("elapsed_time_text"),
            )
            Text(
                text = formatDuration(safeDuration),
                style = MaterialTheme.typography.labelSmall,
                color = SunozaIvory.copy(alpha = 0.8f),
                modifier = Modifier.testTag("total_time_text"),
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = onToggleShuffle,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("shuffle_button"),
            ) {
                Icon(
                    imageVector = Icons.Filled.Shuffle,
                    contentDescription = stringResource(R.string.shuffle),
                    tint = if (shuffleEnabled) SunozaCoral else SunozaIvory.copy(alpha = 0.58f),
                    modifier = Modifier.size(22.dp),
                )
            }

            IconButton(
                onClick = onPrevious,
                modifier = Modifier
                    .size(54.dp)
                    .testTag("previous_button"),
            ) {
                Icon(
                    imageVector = Icons.Filled.SkipPrevious,
                    contentDescription = stringResource(R.string.previous_song),
                    tint = SunozaIvory,
                    modifier = Modifier.size(36.dp),
                )
            }

            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(SunozaIvory)
                    .testTag("play_pause_button_container"),
                contentAlignment = Alignment.Center,
            ) {
                IconButton(
                    onClick = onPlayPause,
                    modifier = Modifier
                        .size(68.dp)
                        .testTag("play_pause_button"),
                ) {
                    if (isBuffering) {
                        CircularProgressIndicator(
                            color = Color(0xFF121216),
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(26.dp),
                        )
                    } else {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (isPlaying) {
                                stringResource(R.string.pause)
                            } else {
                                stringResource(R.string.play)
                            },
                            tint = Color(0xFF121216),
                            modifier = Modifier.size(36.dp),
                        )
                    }
                }
            }

            IconButton(
                onClick = onNext,
                modifier = Modifier
                    .size(54.dp)
                    .testTag("next_button"),
            ) {
                Icon(
                    imageVector = Icons.Filled.SkipNext,
                    contentDescription = stringResource(R.string.next_song),
                    tint = SunozaIvory,
                    modifier = Modifier.size(36.dp),
                )
            }

            IconButton(
                onClick = onCycleRepeat,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("repeat_button"),
            ) {
                val repeatIcon = if (repeatMode == Player.REPEAT_MODE_ONE) {
                    Icons.Filled.RepeatOne
                } else {
                    Icons.Filled.Repeat
                }
                val isRepeatActive = repeatMode != Player.REPEAT_MODE_OFF
                Icon(
                    imageVector = repeatIcon,
                    contentDescription = stringResource(R.string.repeat),
                    tint = if (isRepeatActive) SunozaCoral else SunozaIvory.copy(alpha = 0.58f),
                    modifier = Modifier.size(22.dp),
                )
            }
        }
    }
}

fun formatDuration(ms: Long): String {
    val totalSeconds = (ms.coerceAtLeast(0L) / 1_000L).toInt()
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
