package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.PlaylistWithSongs
import com.example.model.Song
import com.example.ui.theme.SunozaCoral
import com.example.ui.theme.SunozaMutedText

@Composable
fun LyricsEditorDialog(
    song: Song,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
) {
    var lyricsInput by remember(song.id) { mutableStateOf(song.lyricsRaw) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Text(
                text = "Lyrics · ${song.title}",
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            Column {
                Text(
                    text = "Paste [mm:ss.xx] LRC lines for exact sync, or plain lines to auto-space across the track.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = lyricsInput,
                    onValueChange = { lyricsInput = it },
                    label = { Text("Synchronized or plain lyrics") },
                    placeholder = { Text("[00:00.00] First line\n[00:05.50] Second line") },
                    minLines = 6,
                    maxLines = 10,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("lyrics_editor_input"),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(lyricsInput)
                    onDismiss()
                },
                modifier = Modifier.testTag("save_lyrics_button"),
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun AddToPlaylistDialog(
    song: Song,
    playlists: List<PlaylistWithSongs>,
    onDismiss: () -> Unit,
    onToggleSongInPlaylist: (PlaylistWithSongs, Long) -> Unit,
    onCreatePlaylistWithSong: (String, Long) -> Unit,
) {
    var newPlaylistName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Text(
                text = "Add to Playlist",
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "${song.title} · ${song.artist}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    items(playlists, key = { it.id }) { playlist ->
                        val isInPlaylist = playlist.songs.any { it.id == song.id }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleSongInPlaylist(playlist, song.id) }
                                .padding(vertical = 10.dp, horizontal = 4.dp)
                                .testTag("playlist_pick_${playlist.id}"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = playlist.name,
                                    style = MaterialTheme.typography.bodyLarge,
                                )
                                Text(
                                    text = "${playlist.songs.size} songs",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = SunozaMutedText,
                                )
                            }
                            Icon(
                                imageVector = if (isInPlaylist) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                                contentDescription = if (isInPlaylist) "In playlist" else "Add to playlist",
                                tint = if (isInPlaylist) SunozaCoral else SunozaMutedText,
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(
                        value = newPlaylistName,
                        onValueChange = { newPlaylistName = it },
                        placeholder = { Text("New playlist name") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("new_playlist_inline_input"),
                    )
                    TextButton(
                        onClick = {
                            if (newPlaylistName.isNotBlank()) {
                                onCreatePlaylistWithSong(newPlaylistName, song.id)
                                newPlaylistName = ""
                            }
                        },
                        modifier = Modifier.testTag("create_playlist_inline_button"),
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Text("Create")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done")
            }
        },
    )
}

@Composable
fun CreateOrRenamePlaylistDialog(
    title: String,
    initialName: String = "",
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var name by remember(initialName) { mutableStateOf(initialName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Playlist name") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("playlist_name_input"),
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(name.trim())
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("confirm_playlist_name_button"),
            ) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun AuthorizedStreamUrlDialog(
    onDismiss: () -> Unit,
    onAddUrl: (url: String, title: String, artist: String) -> Unit,
) {
    var url by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Add Authorized Stream", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Only HTTPS audio links from authorized Creative Commons & Public Domain providers (archive.org, wikimedia.org, freemusicarchive.org, incompetech.com, opengameart.org, ccmixter.org, soundhelix.com) are accepted.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SunozaMutedText,
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("HTTPS Audio URL") },
                    placeholder = { Text("https://archive.org/download/...") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("authorized_url_input"),
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Song title (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = artist,
                    onValueChange = { artist = it },
                    label = { Text("Singer / Artist (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onAddUrl(url, title, artist) },
                modifier = Modifier.testTag("submit_authorized_url_button"),
            ) {
                Text("Verify & Play")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}
