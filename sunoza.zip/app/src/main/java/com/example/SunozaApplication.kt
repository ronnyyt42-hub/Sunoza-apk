package com.example

import android.app.Application
import com.example.data.local.SunozaDatabase
import com.example.data.remote.ArchiveOrgApi
import com.example.data.repository.MusicRepository
import com.example.player.PlaybackController

class SunozaApplication : Application() {
    val database: SunozaDatabase by lazy { SunozaDatabase.getInstance(this) }
    val archiveApi: ArchiveOrgApi by lazy { ArchiveOrgApi.create() }
    val musicRepository: MusicRepository by lazy {
        MusicRepository(
            context = this,
            dao = database.sunozaDao(),
            archiveApi = archiveApi,
        )
    }
    val playbackController: PlaybackController by lazy { PlaybackController(this) }
}
