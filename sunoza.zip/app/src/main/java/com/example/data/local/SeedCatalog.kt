package com.example.data.local

import android.content.Context
import com.example.R
import com.example.model.SongColorGenerator
import com.example.model.SourceType

object SeedCatalog {
    fun buildSeedSongs(context: Context): List<SongEntity> {
        val pkg = context.packageName
        val now = System.currentTimeMillis()
        var prevColor: Long? = null

        fun nextColor(): Long {
            val c = SongColorGenerator.nextSolidColorArgb(avoidColorArgb = prevColor)
            prevColor = c
            return c
        }

        return listOf(
            SongEntity(
                title = "Midnight Echoes",
                artist = "Aarav Sen",
                audioUri = "android.resource://$pkg/${R.raw.sample_midnight_echoes}",
                durationMs = 24_000L,
                backgroundColorArgb = nextColor(),
                sourceType = SourceType.BUNDLED.name,
                sourceLabel = "Sunoza Sample Audio",
                licenseName = "CC0 Public Domain",
                isFavorite = true,
                lyricsRaw = """
                    [00:00.00]City lights fade into quiet indigo
                    [00:03.00]Footsteps echo softly down the avenue
                    [00:06.00]Every late-night chord carries a memory
                    [00:09.00]Floating through the static and the silver rain
                    [00:12.00]Hold onto the rhythm while the midnight turns
                    [00:15.00]Warm electric keys beneath a velvet sky
                    [00:18.00]Nothing left to rush until the morning breaks
                    [00:21.00]Midnight echoes linger till we meet again
                """.trimIndent(),
                addedAtMs = now,
            ),
            SongEntity(
                title = "Velvet Horizon",
                artist = "Mira Solis",
                audioUri = "android.resource://$pkg/${R.raw.sample_velvet_horizon}",
                durationMs = 24_000L,
                backgroundColorArgb = nextColor(),
                sourceType = SourceType.BUNDLED.name,
                sourceLabel = "Sunoza Sample Audio",
                licenseName = "CC0 Public Domain",
                isFavorite = false,
                lyricsRaw = """
                    [00:00.00]Drifting past the edge of a quiet sea
                    [00:03.00]Amber clouds dissolving in the atmosphere
                    [00:06.00]Every pulse of bass pulls the horizon near
                    [00:09.00]Breathing in the stillness of the evening air
                    [00:12.00]Follow every shimmer where the twilight leads
                    [00:15.00]Weightless like a lantern on a silver tide
                    [00:18.00]Let the synthesizer carry all the weight
                    [00:21.00]Resting on the velvet of a distant shore
                """.trimIndent(),
                addedAtMs = now + 1L,
            ),
            SongEntity(
                title = "Neon Rain",
                artist = "Kaito Mori",
                audioUri = "android.resource://$pkg/${R.raw.sample_neon_rain}",
                durationMs = 24_000L,
                backgroundColorArgb = nextColor(),
                sourceType = SourceType.BUNDLED.name,
                sourceLabel = "Sunoza Sample Audio",
                licenseName = "CC0 Public Domain",
                isFavorite = true,
                lyricsRaw = """
                    [00:00.00]Raindrops trace a lattice on the windowpane
                    [00:03.00]Reflections hum in coral and electric blue
                    [00:06.00]Late train sliding softly through the quiet fog
                    [00:09.00]Counting every heartbeat in the downpour's glow
                    [00:12.00]Chasing crystal notes across the empty street
                    [00:15.00]Every drop a bell inside a midnight song
                    [00:18.00]Time slows down whenever we just listen close
                    [00:21.00]Dancing in the shimmer of the neon rain
                """.trimIndent(),
                addedAtMs = now + 2L,
            ),
            SongEntity(
                title = "Solstice Drift",
                artist = "Elena Vance",
                audioUri = "android.resource://$pkg/${R.raw.sample_solstice_drift}",
                durationMs = 24_000L,
                backgroundColorArgb = nextColor(),
                sourceType = SourceType.BUNDLED.name,
                sourceLabel = "Sunoza Sample Audio",
                licenseName = "CC0 Public Domain",
                isFavorite = false,
                lyricsRaw = """
                    [00:00.00]Golden embers settle on the canyon floor
                    [00:03.00]Plucked strings answer softly to the desert wind
                    [00:06.00]Longest night is turning toward a gentler dawn
                    [00:09.00]Compass needles spinning toward a warmer star
                    [00:12.00]Hear the quiet cadence of the open road
                    [00:15.00]Every note unfolding like a cedar leaf
                    [00:18.00]Stay inside the warmth before the shadows fade
                    [00:21.00]Solstice drift is singing us back home again
                """.trimIndent(),
                addedAtMs = now + 3L,
            ),
        )
    }
}
