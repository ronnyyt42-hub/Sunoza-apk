package com.example.data.remote

data class OnlineTrackCandidate(
    val id: String,
    val title: String,
    val artist: String,
    val streamUrl: String,
    val durationMs: Long,
    val providerName: String,
    val licenseName: String,
    val lyricsRaw: String = "",
)

object CuratedAuthorizedCatalog {
    val featuredTracks: List<OnlineTrackCandidate> = listOf(
        OnlineTrackCandidate(
            id = "soundhelix-1",
            title = "SoundHelix Song 1",
            artist = "T. Schürger",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            durationMs = 372_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons / Free License",
            lyricsRaw = """
                [00:00.00]Algorithmic pulse awakening in stereo
                [00:12.00]Layered arpeggios rising through the dark
                [00:24.00]Steady bassline carrying the motion forward
                [00:36.00]Harmonic chords unfolding in wide space
                [00:48.00]Instrumental drift — tap Edit Lyrics to customize
            """.trimIndent(),
        ),
        OnlineTrackCandidate(
            id = "soundhelix-2",
            title = "SoundHelix Song 2",
            artist = "T. Schürger",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
            durationMs = 425_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons / Free License",
            lyricsRaw = """
                [00:00.00]Electric motifs weaving through the night
                [00:14.00]Syncopated rhythm echoing across the room
                [00:28.00]Melodic shimmer floating over warm bass
                [00:42.00]Instrumental session — authorized open stream
            """.trimIndent(),
        ),
        OnlineTrackCandidate(
            id = "soundhelix-3",
            title = "SoundHelix Song 3",
            artist = "T. Schürger",
            streamUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
            durationMs = 344_000L,
            providerName = "SoundHelix CC",
            licenseName = "Creative Commons / Free License",
            lyricsRaw = """
                [00:00.00]Clean synth chimes opening the third movement
                [00:15.00]Deep groove locking into the midnight tempo
                [00:30.00]Bright overtones glowing against solid dark
                [00:45.00]Authorized open stream via SoundHelix CC
            """.trimIndent(),
        ),
    )
}
