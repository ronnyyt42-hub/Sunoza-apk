package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.Song
import com.example.model.SourceType

@Entity(tableName = "songs")
data class SongEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val artist: String,
    val audioUri: String,
    val durationMs: Long,
    val backgroundColorArgb: Long,
    val sourceType: String,
    val sourceLabel: String,
    val licenseName: String,
    val isFavorite: Boolean = false,
    val lyricsRaw: String = "",
    val addedAtMs: Long = System.currentTimeMillis(),
) {
    fun toDomain(): Song = Song(
        id = id,
        title = title,
        artist = artist,
        audioUri = audioUri,
        durationMs = durationMs,
        backgroundColorArgb = backgroundColorArgb,
        sourceType = runCatching { SourceType.valueOf(sourceType) }.getOrDefault(SourceType.BUNDLED),
        sourceLabel = sourceLabel,
        licenseName = licenseName,
        isFavorite = isFavorite,
        lyricsRaw = lyricsRaw,
        addedAtMs = addedAtMs,
    )
}
