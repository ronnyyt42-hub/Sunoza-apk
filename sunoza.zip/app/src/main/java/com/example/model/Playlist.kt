package com.example.model

data class PlaylistWithSongs(
    val id: Long,
    val name: String,
    val createdAtMs: Long,
    val songs: List<Song>,
)
