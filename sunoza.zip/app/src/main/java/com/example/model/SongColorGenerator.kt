package com.example.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlin.random.Random

object SongColorGenerator {
    /**
     * Generates a random, dark-theme-friendly plain solid background color in HSL space.
     * Controlled saturation and low lightness guarantee high contrast for light lyrics and controls
     * with zero gradients, patterns, or textures.
     */
    fun nextSolidColorArgb(avoidColorArgb: Long? = null): Long {
        var attempt = 0
        while (attempt < 6) {
            val hue = Random.nextFloat() * 360f
            val saturation = 0.36f + Random.nextFloat() * 0.32f // 36% .. 68%
            val lightness = 0.11f + Random.nextFloat() * 0.11f  // 11% .. 22%
            val candidate = Color.hsl(hue = hue, saturation = saturation, lightness = lightness)
            val candidateArgb = candidate.toArgb().toLong() and 0xFFFFFFFFL
            if (avoidColorArgb == null || colorDistance(candidateArgb, avoidColorArgb) > 40) {
                return candidateArgb
            }
            attempt++
        }
        val hue = Random.nextFloat() * 360f
        return Color.hsl(hue, 0.48f, 0.16f).toArgb().toLong() and 0xFFFFFFFFL
    }

    private fun colorDistance(a: Long, b: Long): Int {
        val ar = ((a shr 16) and 0xFF).toInt()
        val ag = ((a shr 8) and 0xFF).toInt()
        val ab = (a and 0xFF).toInt()
        val br = ((b shr 16) and 0xFF).toInt()
        val bg = ((b shr 8) and 0xFF).toInt()
        val bb = (b and 0xFF).toInt()
        return kotlin.math.abs(ar - br) + kotlin.math.abs(ag - bg) + kotlin.math.abs(ab - bb)
    }
}
