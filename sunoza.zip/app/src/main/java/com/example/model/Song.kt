package com.example.model

enum class SourceType(val displayLabel: String) {
    BUNDLED("Built-in Sample"),
    OFFLINE_LOCAL("Offline File"),
    AUTHORIZED_ONLINE("Authorized Stream"),
}

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val audioUri: String,
    val durationMs: Long,
    val backgroundColorArgb: Long,
    val sourceType: SourceType,
    val sourceLabel: String,
    val licenseName: String,
    val isFavorite: Boolean,
    val lyricsRaw: String,
    val addedAtMs: Long,
) {
    val parsedLyrics: List<LyricLine>
        get() = LyricsParser.parse(lyricsRaw, durationMs)
}
